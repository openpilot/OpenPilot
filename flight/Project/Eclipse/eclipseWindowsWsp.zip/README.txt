To use this workspace you have to follow the directions contained in "op_folder"\make\winx86\README.TXT regarding advanced usage.
After that just copy this file contents to the OP root folder.